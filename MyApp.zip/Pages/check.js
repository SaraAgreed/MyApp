  /*  <View 
                style={styles.chatView}
                >   
                    <Text
                    style={styles.chatText}
                    onPress={() => this.props.navigation.navigate("Authenticate")}
                    >
                    GROUP 1
                    </Text>     
                </View>
                <View style={styles.chatView}> 
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 2
                    </Text>
                </View>
                <View style={styles.chatView}> 
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 3
                    </Text>
                    </View>    
                <View style={styles.chatView}>
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 4
                    </Text>
                </View>
                <View style={styles.chatView}>   
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 5
                    </Text>     
                </View>
                <View style={styles.chatView}> 
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 6
                    </Text>
                </View>
                <View style={styles.chatView}> 
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 7
                    </Text>
                    </View>    
                <View style={styles.chatView}> 
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 8
                    </Text>
                    </View>
                <View style={styles.chatView}>
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 9
                    </Text>
                </View>
                <View style={styles.chatView}>
                    <Text
                    style={styles.chatText}
                    >
                    GROUP 10
                    </Text>           
                </View> */



                <View style={styles.componentContainer}>
            
                <TextInput
                    placeholder = "Search..."
                    placeholderTextColor = '#95A5A6'
                    underlineColorAndroid='transparent'                       
                    style={styles.input}
                />

                <TouchableOpacity style = {styles.buttonContainer}>
                    <Image
                        source={require('./img/isearch.png')}
                        style={styles.sendbtn}
                    />
                </TouchableOpacity>

            </View>


import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ListView,
    TextInput,
    TouchableOpacity,
    Image,
} from 'react-native';

export default class Home extends Component{
        static navigationOptions={
            title:'ChatApp'
        }

        constructor(props){
            super(props);
            this.state={
                dataSource:new ListView.DataSource({rowHasChanged:(r1,r2)=>r1 !== r2}),
                link: 'http://testingoncloud.com/chat/index.php/chatroom/chatroomList',
            } 
        } 
        componentDidMount(){
            fetch(this.state.link)
            .then((response) => response.json())
            .then((responseJson) => {  
                dataSource = responseJson;
                this.setState=({
                    dataSource: this.state.dataSource.cloneWithRows(responseJson.response.data)
                })   
            })
            .catch((error) => {
                console.error(error);
            });
        }

    render() {
        
        return(
            <View style={styles.container}>

            <ListView 
                dataSource={this.state.dataSource}
                renderRow={(rowData)=>
        <Text>{rowData.chatroom_name}</Text> 
            }
            />             
            </View>
        );
    } 
}


const styles = StyleSheet.create({
    container: {
        flex:1,
    padding:25
        //backgroundColor:"#f5f6fa"
    },
    chatView: {
        justifyContent:'center',
        alignItems:'center',
        height:50,
        backgroundColor: 'rgba(0,0,0,0.05)',
        marginTop:8
        
    },
    chatText : {
        fontFamily:'serif'
    },
    
    componentContainer: {
        flex:1,
        flexDirection:'row',
        alignItems:'flex-start',
        padding:5,
        
    },
    input: {
        padding:10,
        height: 40,
        marginBottom: 10,
        width:300,
        borderWidth:1,
        borderColor:'#264348',
        marginTop:6,
    },
    buttonContainer:
    {
        padding:5,
    },
    sendbtn: {
        width:40,
        height:40
    },
    
  });
 
